import pyodbc

def connect_to_database():
    try:
        conn = pyodbc.connect(
            'DSN=samp1;'
            'UID=inst23;'
            'PWD=Sujiaming123;'
        )
        print("Database connection established successfully.")
        return conn
    except pyodbc.Error as e:
        print(f"Error connecting to database: {e}")
        return None

def validate_input(prompt, max_length=None, data_type=str, nullable=True):
    while True:
        user_input = input(prompt)
        if not nullable and not user_input:
            print("Input cannot be empty. Please try again.")
        elif max_length and len(user_input) > max_length:
            print(f"Input too long. Please enter up to {max_length} characters.")
        elif data_type == int:
            try:
                return int(user_input)
            except ValueError:
                print("Invalid input. Please enter a valid integer.")
        elif data_type == float:
            try:
                return float(user_input)
            except ValueError:
                print("Invalid input. Please enter a valid decimal number.")
        else:
            return user_input

def insert_employee(conn):
    emp_no = validate_input("Enter employee number: ", 6, str, False)
    first_name = validate_input("Enter employee first name: ", 12, str, False)
    last_name = validate_input("Enter employee last name: ", 15, str, False)
    ed_level = validate_input("Enter education level: ", None, int, False)

    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO EMPLOYEE (EMPNO, FIRSTNME, LASTNAME, EDLEVEL) 
            VALUES (?, ?, ?, ?)
        """, (emp_no, first_name, last_name, ed_level))
        conn.commit()
        print("Employee inserted successfully.")
    except pyodbc.Error as e:
        print(f"Error inserting employee: {e}")
    finally:
        cursor.close()

def delete_employee(conn):
    emp_no = validate_input("Enter employee number to delete: ", 6, str, False)

    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM EMPLOYEE WHERE EMPNO = ?", (emp_no,))
        conn.commit()
        if cursor.rowcount == 0:
            print("Employee not found.")
        else:
            print("Employee deleted successfully.")
    except pyodbc.Error as e:
        print(f"Error deleting employee: {e}")
    finally:
        cursor.close()

def update_employee(conn):
    emp_no = validate_input("Enter employee number to update: ", 6, str, False)
    last_name = validate_input("Enter new last name: ", 15, str, False)

    try:
        cursor = conn.cursor()
        cursor.execute("UPDATE EMPLOYEE SET LASTNAME = ? WHERE EMPNO = ?", (last_name, emp_no))
        conn.commit()
        if cursor.rowcount == 0:
            print("Employee not found.")
        else:
            print("Employee updated successfully.")
    except pyodbc.Error as e:
        print(f"Error updating employee: {e}")
    finally:
        cursor.close()

def search_employee(conn):
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT EMPNO, FIRSTNME, LASTNAME, EDLEVEL FROM EMPLOYEE")

        print("Search results:")
        columns = [column[0] for column in cursor.description]
        max_widths = [6, 12, 15, 5]
        
        # 打印列名
        for i, column in enumerate(columns):
            print(f"{column:{max_widths[i]}}", end="  ")
        print()

        # 打印每行数据
        for row in cursor.fetchall():
            for i, col in enumerate(row):
                print(f"{col:{max_widths[i]}}", end="  ")
            print()
    except pyodbc.Error as e:
        print(f"Error fetching employees: {e}")
    finally:
        cursor.close()

def main():
    conn = connect_to_database()
    if not conn:
        return

    try:
        while True:
            print("\n--- Employee Database ---")
            print("1. Insert Employee")
            print("2. Delete Employee")
            print("3. Update Employee")
            print("4. Search Employees")
            print("0. Exit")

            choice = input("Enter your choice: ")
            if choice == '0':
                break
            elif choice == '1':
                insert_employee(conn)
            elif choice == '2':
                delete_employee(conn)
            elif choice == '3':
                update_employee(conn)
            elif choice == '4':
                search_employee(conn)
            else:
                print("Invalid choice. Please try again.")
    finally:
        conn.close()

if __name__ == '__main__':
    main()
