static char sqla_program_id[292] =
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x58','\x41','\x5a','\x78','\x54','\x4d','\x47','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x53','\x4a','\x4d','\x20','\x20','\x20',
 '\x20','\x20','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x44','\x59','\x4e','\x41','\x4d','\x49','\x43','\x53','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo =
{ {'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {' ',' ',' ',' '} };


static const short sqlIsLiteral = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "DynamicSQL.sqc"
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <sqlca.h>
#include <sql.h>
#include <sqlenv.h>
#include <sqlda.h>

void clearInputBuffer();
int getValidNumber(char* prompt);
double getValidDoubleNumber(char* prompt);
char* getInput(const char* prompt, const int maxLen);
int isAllVisibleCharacters(const char* str, const int len);
void displayMenu();
void executeQuery();
void executeInsert();
void executeUpdate();
void executeDelete();

void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

int getValidNumber(char* prompt) {
    int number = -1;
    printf("Enter %s: ", prompt);

    while (scanf_s("%d", &number) != 1) {
        while (getchar() != '\n')
            ;
        printf("\nInvalid input, try again please\n");
    }

    clearInputBuffer();
    return number;
}

double getValidDoubleNumber(char* prompt) {
    double number = -1.0;
    printf("Enter %s: ", prompt);

    while (scanf_s("%lf", &number) != 1) {
        while (getchar() != '\n')
            ;
        printf("\nInvalid input, try again please\n");
    }

    clearInputBuffer();
    return number;
}

char* getInput(const char* prompt, const int maxLen) {
    char input[256];
    printf("Please enter %s: ", prompt);

    while (1) {
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0';

        if (strlen(input) == 0 || !isAllVisibleCharacters(input, maxLen)) {
            printf("\nInvalid input. Please input again: ");
        }
        else {
            break;
        }
    }

    return _strdup(input);
}

int isAllVisibleCharacters(const char* str, const int len) {
    if (strlen(str) > len) {
        return 0;
    }

    for (int i = 0; str[i] != '\0'; i++) {
        if (!(str[i] >= 32 && str[i] <= 126)) {
            return 0;
        }
    }

    return 1;
}

void displayMenu() {
    printf("\n\n\n\n\n=============================\n");
    printf("EMPLOYEE MANAGEMENT SYSTEM\n");
    printf("=============================\n");
    printf("Main Menu:\n");
    printf("1. Insert into EMPLOYEE\n");
    printf("2. Select from EMPLOYEE\n");
    printf("3. Update EMPLOYEE\n");
    printf("4. Delete from EMPLOYEE\n");
    printf("0. Exit\n");
}

void executeQuery() {
    // Include the SQLCA data structure variable

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
    struct sqlca sqlca;


#line 99 "DynamicSQL.sqc"

    // Define the SQL host variables needed

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 101 "DynamicSQL.sqc"

    char     EmployeeNo[7];
    char     LastName[16];
    double   Salary;
    char     JobType[9];

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 106 "DynamicSQL.sqc"


    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 109 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 109 "DynamicSQL.sqc"
        sqlaaloc(2, 3, 1, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 109 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 109 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 109 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 109 "DynamicSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 109 "DynamicSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 109 "DynamicSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 109 "DynamicSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 109 "DynamicSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 109 "DynamicSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 109 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 109 "DynamicSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 109 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 109 "DynamicSQL.sqc"


    // Prompt for job type
    strcpy(JobType, getInput("JOB TYPE", 8));

    // Define a dynamic SELECT SQL statement
    char SQLStmt[256] = "SELECT EMPNO, LASTNAME, SALARY FROM EMPLOYEE WHERE JOB = ? ";

    // Prepare the SQL statement

/*
EXEC SQL PREPARE SQL_STMT FROM :SQLStmt;
*/

    {
#line 118 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 118 "DynamicSQL.sqc"
        sqlastls(0, SQLStmt, 0L);
#line 118 "DynamicSQL.sqc"
        sqlacall((unsigned short)27, 1, 0, 0, 0L);
#line 118 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 118 "DynamicSQL.sqc"



    /*
    EXEC SQL DECLARE C1 CURSOR FOR SQL_STMT;
    */

#line 120 "DynamicSQL.sqc"



    /*
    EXEC SQL OPEN C1 USING :JobType;
    */

    {
#line 122 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 122 "DynamicSQL.sqc"
        sqlaaloc(2, 1, 2, 0L);
        {
            struct sqla_setdata_list sql_setdlist[1];
#line 122 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 9;
#line 122 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)JobType;
#line 122 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 122 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 1, sql_setdlist, 0L, 0L);
        }
#line 122 "DynamicSQL.sqc"
        sqlacall((unsigned short)26, 1, 2, 0, 0L);
#line 122 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 122 "DynamicSQL.sqc"


    // If the cursor was opened successfully, retrieve and display all records available
    while (1) {
        // Retrieve the current record from the cursor

/*
EXEC SQL FETCH C1 INTO :EmployeeNo, :LastName, :Salary;
*/

        {
#line 127 "DynamicSQL.sqc"
            sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 127 "DynamicSQL.sqc"
            sqlaaloc(3, 3, 3, 0L);
            {
                struct sqla_setdata_list sql_setdlist[3];
#line 127 "DynamicSQL.sqc"
                sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[0].sqldata = (void*)EmployeeNo;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[0].sqlind = 0L;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 16;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[1].sqldata = (void*)LastName;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[1].sqlind = 0L;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[2].sqltype = 480; sql_setdlist[2].sqllen = 8;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[2].sqldata = (void*)&Salary;
#line 127 "DynamicSQL.sqc"
                sql_setdlist[2].sqlind = 0L;
#line 127 "DynamicSQL.sqc"
                sqlasetdata(3, 0, 3, sql_setdlist, 0L, 0L);
            }
#line 127 "DynamicSQL.sqc"
            sqlacall((unsigned short)25, 1, 0, 3, 0L);
#line 127 "DynamicSQL.sqc"
            sqlastop(0L);
        }

#line 127 "DynamicSQL.sqc"


        // Display the record retrieved
        if (sqlca.sqlcode == SQL_RC_OK) {
            printf("%-8s %-16s %.2lf\n", EmployeeNo, LastName, Salary);
        }
        else {
            break;
        }
    }

    // Close the cursor

/*
EXEC SQL CLOSE C1;
*/

    {
#line 139 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 139 "DynamicSQL.sqc"
        sqlacall((unsigned short)20, 1, 0, 0, 0L);
#line 139 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 139 "DynamicSQL.sqc"


    // Commit the transaction

/*
EXEC SQL COMMIT;
*/

    {
#line 142 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 142 "DynamicSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 142 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 142 "DynamicSQL.sqc"


    // Terminate the database connection

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 145 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 145 "DynamicSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 145 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 145 "DynamicSQL.sqc"

}

void executeInsert() {
    // Include the SQLCA data structure variable

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
    struct sqlca sqlca;


#line 150 "DynamicSQL.sqc"

    // Define the SQL host variables needed

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 152 "DynamicSQL.sqc"

    char     EmployeeNo[7];
    char     FirstName[13];
    char     LastName[16];
    sqlint32      EdLevel;
    double   Salary;
    char     JobType[9];

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 159 "DynamicSQL.sqc"


    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 162 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 162 "DynamicSQL.sqc"
        sqlaaloc(2, 3, 4, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 162 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 162 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 162 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 162 "DynamicSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 162 "DynamicSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 162 "DynamicSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 162 "DynamicSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 162 "DynamicSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 162 "DynamicSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 162 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 162 "DynamicSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 162 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 162 "DynamicSQL.sqc"


    // Prompt for employee details
    strcpy(EmployeeNo, getInput("EMPNO", 6));
    strcpy(FirstName, getInput("FIRSTNAME", 12));
    strcpy(LastName, getInput("LASTNAME", 15));
    EdLevel = getValidNumber("EDLEVEL");
    Salary = getValidDoubleNumber("SALARY");
    strcpy(JobType, getInput("JOB TYPE", 8));

    // Define a dynamic INSERT SQL statement
    char SQLStmt[256] = "INSERT INTO EMPLOYEE (EMPNO, FIRSTNME, LASTNAME, EDLEVEL, SALARY, JOB) VALUES (?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement

/*
EXEC SQL PREPARE SQL_STMT FROM :SQLStmt;
*/

    {
#line 176 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 176 "DynamicSQL.sqc"
        sqlastls(0, SQLStmt, 0L);
#line 176 "DynamicSQL.sqc"
        sqlacall((unsigned short)27, 1, 0, 0, 0L);
#line 176 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 176 "DynamicSQL.sqc"


    // Execute the SQL statement

/*
EXEC SQL EXECUTE SQL_STMT USING :EmployeeNo, :FirstName, :LastName, :EdLevel, :Salary, :JobType;
*/

    {
#line 179 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 179 "DynamicSQL.sqc"
        sqlaaloc(2, 6, 5, 0L);
        {
            struct sqla_setdata_list sql_setdlist[6];
#line 179 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)EmployeeNo;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 13;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[1].sqldata = (void*)FirstName;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 16;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[2].sqldata = (void*)LastName;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[3].sqltype = 496; sql_setdlist[3].sqllen = 4;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[3].sqldata = (void*)&EdLevel;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[3].sqlind = 0L;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[4].sqltype = 480; sql_setdlist[4].sqllen = 8;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[4].sqldata = (void*)&Salary;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[4].sqlind = 0L;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[5].sqltype = 460; sql_setdlist[5].sqllen = 9;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[5].sqldata = (void*)JobType;
#line 179 "DynamicSQL.sqc"
            sql_setdlist[5].sqlind = 0L;
#line 179 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 6, sql_setdlist, 0L, 0L);
        }
#line 179 "DynamicSQL.sqc"
        sqlacall((unsigned short)24, 1, 2, 0, 0L);
#line 179 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 179 "DynamicSQL.sqc"


    if (sqlca.sqlcode == SQL_RC_OK) {
        printf("insert successfully\n");
    }
    else {
        printf("Error Code1: %d\n", sqlca.sqlcode);
    }

    // Commit the transaction

/*
EXEC SQL COMMIT;
*/

    {
#line 189 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 189 "DynamicSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 189 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 189 "DynamicSQL.sqc"


    // Terminate the database connection

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 192 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 192 "DynamicSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 192 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 192 "DynamicSQL.sqc"

}

void executeUpdate() {
    // Include the SQLCA data structure variable

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
    struct sqlca sqlca;


#line 197 "DynamicSQL.sqc"

    // Define the SQL host variables needed

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 199 "DynamicSQL.sqc"

    char     EmployeeNo[7];
    char     JobType[9];

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 202 "DynamicSQL.sqc"


    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 205 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 205 "DynamicSQL.sqc"
        sqlaaloc(2, 3, 6, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 205 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 205 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 205 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 205 "DynamicSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 205 "DynamicSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 205 "DynamicSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 205 "DynamicSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 205 "DynamicSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 205 "DynamicSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 205 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 205 "DynamicSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 205 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 205 "DynamicSQL.sqc"


    // Prompt for EmployeeNo
    strcpy(EmployeeNo, getInput("EMPNO TO UPDATE", 6));

    // Prompt for job type
    strcpy(JobType, getInput("JOB TYPE TO UPDATE", 8));

    // Define a dynamic UPDATE SQL statement
    char SQLStmt[256] = "UPDATE EMPLOYEE SET JOB = ? WHERE EMPNO = ?";

    // Prepare the SQL statement

/*
EXEC SQL PREPARE SQL_STMT FROM :SQLStmt;
*/

    {
#line 217 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 217 "DynamicSQL.sqc"
        sqlastls(0, SQLStmt, 0L);
#line 217 "DynamicSQL.sqc"
        sqlacall((unsigned short)27, 1, 0, 0, 0L);
#line 217 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 217 "DynamicSQL.sqc"


    // Execute the SQL statement

/*
EXEC SQL EXECUTE SQL_STMT USING :JobType, :EmployeeNo;
*/

    {
#line 220 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 220 "DynamicSQL.sqc"
        sqlaaloc(2, 2, 7, 0L);
        {
            struct sqla_setdata_list sql_setdlist[2];
#line 220 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 9;
#line 220 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)JobType;
#line 220 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 220 "DynamicSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 7;
#line 220 "DynamicSQL.sqc"
            sql_setdlist[1].sqldata = (void*)EmployeeNo;
#line 220 "DynamicSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 220 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 2, sql_setdlist, 0L, 0L);
        }
#line 220 "DynamicSQL.sqc"
        sqlacall((unsigned short)24, 1, 2, 0, 0L);
#line 220 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 220 "DynamicSQL.sqc"


    if (sqlca.sqlcode == SQL_RC_OK) {
        printf("update successfully\n");
    }
    else {
        printf("Error Code1: %d\n", sqlca.sqlcode);
    }

    // Commit the transaction

/*
EXEC SQL COMMIT;
*/

    {
#line 230 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 230 "DynamicSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 230 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 230 "DynamicSQL.sqc"


    // Terminate the database connection

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 233 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 233 "DynamicSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 233 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 233 "DynamicSQL.sqc"

}

void executeDelete() {
    // Include the SQLCA data structure variable

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
    struct sqlca sqlca;


#line 238 "DynamicSQL.sqc"

    // Define the SQL host variables needed

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 240 "DynamicSQL.sqc"

    char     EmployeeNo[7];

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 242 "DynamicSQL.sqc"


    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 245 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 245 "DynamicSQL.sqc"
        sqlaaloc(2, 3, 8, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 245 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 245 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 245 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 245 "DynamicSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 245 "DynamicSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 245 "DynamicSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 245 "DynamicSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 245 "DynamicSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 245 "DynamicSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 245 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 245 "DynamicSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 245 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 245 "DynamicSQL.sqc"


    // Prompt for employee number
    strcpy(EmployeeNo, getInput("EMPNO TO DELETE", 6));

    // Define a dynamic DELETE SQL statement  
    char SQLStmt[256] = "DELETE FROM EMPLOYEE WHERE EMPNO = ?";

    // Prepare the SQL statement

/*
EXEC SQL PREPARE SQL_STMT FROM :SQLStmt;
*/

    {
#line 254 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 254 "DynamicSQL.sqc"
        sqlastls(0, SQLStmt, 0L);
#line 254 "DynamicSQL.sqc"
        sqlacall((unsigned short)27, 1, 0, 0, 0L);
#line 254 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 254 "DynamicSQL.sqc"


    // Execute the SQL statement

/*
EXEC SQL EXECUTE SQL_STMT USING :EmployeeNo;
*/

    {
#line 257 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 257 "DynamicSQL.sqc"
        sqlaaloc(2, 1, 9, 0L);
        {
            struct sqla_setdata_list sql_setdlist[1];
#line 257 "DynamicSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 257 "DynamicSQL.sqc"
            sql_setdlist[0].sqldata = (void*)EmployeeNo;
#line 257 "DynamicSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 257 "DynamicSQL.sqc"
            sqlasetdata(2, 0, 1, sql_setdlist, 0L, 0L);
        }
#line 257 "DynamicSQL.sqc"
        sqlacall((unsigned short)24, 1, 2, 0, 0L);
#line 257 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 257 "DynamicSQL.sqc"


    if (sqlca.sqlcode == SQL_RC_OK) {
        printf("delete over\n");
    }
    else {
        printf("Error Code1: %d\n", sqlca.sqlcode);
    }

    // Commit the transaction

/*
EXEC SQL COMMIT;
*/

    {
#line 267 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 267 "DynamicSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 267 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 267 "DynamicSQL.sqc"


    // Terminate the database connection

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 270 "DynamicSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 270 "DynamicSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 270 "DynamicSQL.sqc"
        sqlastop(0L);
    }

#line 270 "DynamicSQL.sqc"

}

void handleUserChoice(int choice) {
    switch (choice) {
    case 1:
        executeInsert();
        break;
    case 2:
        executeQuery();
        break;
    case 3:
        executeUpdate();
        break;
    case 4:
        executeDelete();
        break;
    default:
        printf("Invalid Input! Please try again!\n");
        printf("\n");
        break;
    }
}

int main() {
    SetConsoleOutputCP(65001);
    int choice = -1;
    while (1) {
        displayMenu();

        choice = getValidNumber("your choice");

        if (choice == 0) {
            printf("EXIT...\n");
            return 0;
        }

        handleUserChoice(choice);
    }

    return 0;
}