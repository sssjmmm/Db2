static char sqla_program_id[292] =
{
 '\xac','\x0','\x41','\x45','\x41','\x56','\x41','\x49','\x4d','\x41','\x63','\x66','\x53','\x4d','\x47','\x6f','\x30','\x31','\x31','\x31',
 '\x31','\x20','\x32','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x20','\x8','\x0','\x53','\x4a','\x4d','\x20','\x20','\x20',
 '\x20','\x20','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x8','\x0','\x53','\x54','\x41','\x54','\x49','\x43','\x53','\x51','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0',
 '\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0','\x0'
};

#include "sqladef.h"

static struct sqla_runtime_info sqla_rtinfo =
{ {'S','Q','L','A','R','T','I','N'}, sizeof(wchar_t), 0, {' ',' ',' ',' '} };


static const short sqlIsLiteral = SQL_IS_LITERAL;
static const short sqlIsInputHvar = SQL_IS_INPUT_HVAR;


#line 1 "StaticSQL.sqc"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sqlca.h>
#include <sql.h>
#include <sqlenv.h>
#include <sqlda.h>

void handleSqlcaError();


// Function declarations for CRUD operations
void insertEmployee();
void selectEmployees();
void updateEmployee();
void deleteEmployee();
void fetchDataAndDisplay(char* query);

// Utils
int isAllVisibleCharacters(const char* str, const int len);
char* getInput(const char* prompt, const int maxLen);
int getValidNumber(char* prompt);
double getValidDoubleNumber(char* prompt);
void clearInputBuffer();

void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

int getValidNumber(char* prompt) {
    int number = -1;
    printf("Enter %s: ", prompt);

    while (scanf_s("%d", &number) != 1) {
        while (getchar() != '\n')
            ;
        printf("\nInvalid input, try again please\n");
    }

    clearInputBuffer();
    return number;
}

double getValidDoubleNumber(char* prompt) {
    double number = -1.0;
    printf("Enter %s: ", prompt);

    while (scanf_s("%lf", &number) != 1) {
        while (getchar() != '\n')
            ;
        printf("\nInvalid input, try again please\n");
    }

    clearInputBuffer();
    return number;
}

char* getInput(const char* prompt, const int maxLen) {
    char input[256];
    printf("Please enter %s: ", prompt);

    while (1) {
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0';

        if (strlen(input) == 0 || !isAllVisibleCharacters(input, maxLen)) {
            printf("\nInvalid input. Please input again: ");
        }
        else {
            break;
        }
    }

    return _strdup(input);
}

int isAllVisibleCharacters(const char* str, const int len) {
    if (strlen(str) > len) {
        return 0;
    }

    for (int i = 0; str[i] != '\0'; i++) {
        if (!(str[i] >= 32 && str[i] <= 126)) {
            return 0;
        }
    }

    return 1;
}

// Define the SQLCA Data Structure Variable

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 92 "StaticSQL.sqc"


void processUserChoice(int choice) {
    switch (choice) {
    case 1:
        insertEmployee();
        break;
    case 2:
        selectEmployees();
        break;
    case 3:
        updateEmployee();
        break;
    case 4:
        deleteEmployee();
        break;
    default:
        printf("Invalid, please try again.\n");
        break;
    }
}


void showMenu() {
    printf("\n\n\n\n\n=============================\n");
    printf("EMPLOYEE MANAGEMENT SYSTEM\n");
    printf("=============================\n");
    printf("Main Menu:\n");
    printf("1. Insert into EMPLOYEE\n");
    printf("2. Select from EMPLOYEE\n");
    printf("3. Update EMPLOYEE\n");
    printf("4. Delete from EMPLOYEE\n");
    printf("0. Exit\n");
}

// Define the SQLCA Data Structure Variable

/*
EXEC SQL INCLUDE SQLCA;
*/

/* SQL Communication Area - SQLCA - structures and constants */
#include "sqlca.h"
struct sqlca sqlca;


#line 128 "StaticSQL.sqc"


int main() {
    int choice = -1;

    while (choice != 0) {
        // Show the main menu
        showMenu();
        choice = getValidNumber("your choice");
        if (choice == 0) {
            printf("Exit...\n");
        }
        else {
            processUserChoice(choice);
        }
    }

    // Terminate the database connection

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 145 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 145 "StaticSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 145 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 145 "StaticSQL.sqc"


    // Return control to the operating system
    return 0;
}

void handleSqlcaError() {
    printf("SQL Error: %ld\n", sqlca.sqlcode);
}

void insertEmployee() {
    // Use EXEC SQL statements and host variables to perform the insert operation

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 157 "StaticSQL.sqc"

    char     EmployeeNo[7];
    char     FirstName[13];
    char     LastName[16];
    sqlint32      EdLevel;
    double   Salary;

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 163 "StaticSQL.sqc"


    // Get input
    strcpy(EmployeeNo, getInput("EMPNO", 6));
    strcpy(FirstName, getInput("FIRSTNAME", 12));
    strcpy(LastName, getInput("LASTNAME", 15));
    EdLevel = getValidNumber("EDLEVEL");
    Salary = getValidDoubleNumber("SALARY");

    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 173 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 173 "StaticSQL.sqc"
        sqlaaloc(2, 3, 1, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 173 "StaticSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 173 "StaticSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 173 "StaticSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 173 "StaticSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 173 "StaticSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 173 "StaticSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 173 "StaticSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 173 "StaticSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 173 "StaticSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 173 "StaticSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 173 "StaticSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 173 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 173 "StaticSQL.sqc"



    /*
    EXEC SQL INSERT INTO EMPLOYEE (EMPNO, FIRSTNME, LASTNAME, EDLEVEL, SALARY) VALUES (:EmployeeNo, :FirstName, :LastName, :EdLevel, :Salary);
    */

    {
#line 175 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 175 "StaticSQL.sqc"
        sqlaaloc(2, 5, 2, 0L);
        {
            struct sqla_setdata_list sql_setdlist[5];
#line 175 "StaticSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 175 "StaticSQL.sqc"
            sql_setdlist[0].sqldata = (void*)EmployeeNo;
#line 175 "StaticSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 175 "StaticSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 13;
#line 175 "StaticSQL.sqc"
            sql_setdlist[1].sqldata = (void*)FirstName;
#line 175 "StaticSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 175 "StaticSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 16;
#line 175 "StaticSQL.sqc"
            sql_setdlist[2].sqldata = (void*)LastName;
#line 175 "StaticSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 175 "StaticSQL.sqc"
            sql_setdlist[3].sqltype = 496; sql_setdlist[3].sqllen = 4;
#line 175 "StaticSQL.sqc"
            sql_setdlist[3].sqldata = (void*)&EdLevel;
#line 175 "StaticSQL.sqc"
            sql_setdlist[3].sqlind = 0L;
#line 175 "StaticSQL.sqc"
            sql_setdlist[4].sqltype = 480; sql_setdlist[4].sqllen = 8;
#line 175 "StaticSQL.sqc"
            sql_setdlist[4].sqldata = (void*)&Salary;
#line 175 "StaticSQL.sqc"
            sql_setdlist[4].sqlind = 0L;
#line 175 "StaticSQL.sqc"
            sqlasetdata(2, 0, 5, sql_setdlist, 0L, 0L);
        }
#line 175 "StaticSQL.sqc"
        sqlacall((unsigned short)24, 1, 2, 0, 0L);
#line 175 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 175 "StaticSQL.sqc"

    if (sqlca.sqlcode == 0) {
        printf("Employee inserted successfully.\n");
    }
    else {
        printf("Failed to insert employee.\n");
        handleSqlcaError();
    }

    // Commit The Transaction

/*
EXEC SQL COMMIT;
*/

    {
#line 184 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 184 "StaticSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 184 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 184 "StaticSQL.sqc"


    // Disconnect from the database

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 187 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 187 "StaticSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 187 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 187 "StaticSQL.sqc"

}

void fetchDataAndDisplay(char* employeeNo) {

    /*
    EXEC SQL BEGIN DECLARE SECTION;
    */

#line 191 "StaticSQL.sqc"

    char EmployeeNo[7];
    char FirstName[13];
    char LastName[16];
    sqlint32 EdLevel;
    double Salary;

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 197 "StaticSQL.sqc"


    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 200 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 200 "StaticSQL.sqc"
        sqlaaloc(2, 3, 3, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 200 "StaticSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 200 "StaticSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 200 "StaticSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 200 "StaticSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 200 "StaticSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 200 "StaticSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 200 "StaticSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 200 "StaticSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 200 "StaticSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 200 "StaticSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 200 "StaticSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 200 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 200 "StaticSQL.sqc"



    /*
    EXEC SQL DECLARE C1 CURSOR FOR
            SELECT EMPNO, FIRSTNME, LASTNAME, EDLEVEL, SALARY FROM EMPLOYEE;
    */

#line 203 "StaticSQL.sqc"


    // Open the cursor

/*
EXEC SQL OPEN C1;
*/

    {
#line 206 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 206 "StaticSQL.sqc"
        sqlacall((unsigned short)26, 2, 0, 0, 0L);
#line 206 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 206 "StaticSQL.sqc"


    // Fetch and display all records available
    while (sqlca.sqlcode == SQL_RC_OK) {

        /*
        EXEC SQL FETCH C1 INTO :EmployeeNo, :FirstName, :LastName, :EdLevel, :Salary;
        */

        {
#line 210 "StaticSQL.sqc"
            sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 210 "StaticSQL.sqc"
            sqlaaloc(3, 5, 4, 0L);
            {
                struct sqla_setdata_list sql_setdlist[5];
#line 210 "StaticSQL.sqc"
                sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 210 "StaticSQL.sqc"
                sql_setdlist[0].sqldata = (void*)EmployeeNo;
#line 210 "StaticSQL.sqc"
                sql_setdlist[0].sqlind = 0L;
#line 210 "StaticSQL.sqc"
                sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 13;
#line 210 "StaticSQL.sqc"
                sql_setdlist[1].sqldata = (void*)FirstName;
#line 210 "StaticSQL.sqc"
                sql_setdlist[1].sqlind = 0L;
#line 210 "StaticSQL.sqc"
                sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 16;
#line 210 "StaticSQL.sqc"
                sql_setdlist[2].sqldata = (void*)LastName;
#line 210 "StaticSQL.sqc"
                sql_setdlist[2].sqlind = 0L;
#line 210 "StaticSQL.sqc"
                sql_setdlist[3].sqltype = 496; sql_setdlist[3].sqllen = 4;
#line 210 "StaticSQL.sqc"
                sql_setdlist[3].sqldata = (void*)&EdLevel;
#line 210 "StaticSQL.sqc"
                sql_setdlist[3].sqlind = 0L;
#line 210 "StaticSQL.sqc"
                sql_setdlist[4].sqltype = 480; sql_setdlist[4].sqllen = 8;
#line 210 "StaticSQL.sqc"
                sql_setdlist[4].sqldata = (void*)&Salary;
#line 210 "StaticSQL.sqc"
                sql_setdlist[4].sqlind = 0L;
#line 210 "StaticSQL.sqc"
                sqlasetdata(3, 0, 5, sql_setdlist, 0L, 0L);
            }
#line 210 "StaticSQL.sqc"
            sqlacall((unsigned short)25, 2, 0, 3, 0L);
#line 210 "StaticSQL.sqc"
            sqlastop(0L);
        }

#line 210 "StaticSQL.sqc"


        if (sqlca.sqlcode == SQL_RC_OK) {
            if (employeeNo == NULL) {
                printf("%-8s %-13s %-16s %-10d %lf\n", EmployeeNo, FirstName, LastName, EdLevel, Salary);
            }
            else {
                if (strcmp(employeeNo, EmployeeNo) == 0) {
                    printf("%-8s %-13s %-16s %-10d %lf\n", EmployeeNo, FirstName, LastName, EdLevel, Salary);
                }
            }
        }
    }

    // Close the cursor

/*
EXEC SQL CLOSE C1;
*/

    {
#line 224 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 224 "StaticSQL.sqc"
        sqlacall((unsigned short)20, 2, 0, 0, 0L);
#line 224 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 224 "StaticSQL.sqc"


    // Commit The Transaction

/*
EXEC SQL COMMIT;
*/

    {
#line 227 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 227 "StaticSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 227 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 227 "StaticSQL.sqc"


    // Disconnect from the database

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 230 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 230 "StaticSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 230 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 230 "StaticSQL.sqc"

}

void selectEmployees() {
    int choice = -1;

    printf("Select Employees:\n");
    printf("1: select all employees\n");
    printf("2: select by empno\n");
    printf("other. Exit\n");

    choice = getValidNumber("your choice");

    switch (choice) {
    case 1:
        fetchDataAndDisplay(NULL);
        break;
    case 2: {
        char employeeNoInput[7];
        strcpy(employeeNoInput, getInput("EMPNO", 6));
        fetchDataAndDisplay(employeeNoInput);
        break;
    }
    default:
        printf("Exiting...\n");
        break;
    }
}

void updateEmployee() {
    // Use EXEC SQL statements and host variables to perform the update operation

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 261 "StaticSQL.sqc"

    char     EmployeeNo[7];
    char     FirstName[13];
    char     LastName[16];
    sqlint32      EdLevel;
    double   Salary;

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 267 "StaticSQL.sqc"


    strcpy(EmployeeNo, getInput("EMPNO TO UPDATE", 6));
    strcpy(FirstName, getInput("FIRSTNAME TO UPDATE", 12));
    strcpy(LastName, getInput("LASTNAME TO UPDATE", 15));
    EdLevel = getValidNumber("EDLEVEL TO UPDATE");
    Salary = getValidDoubleNumber("SALARY TO UPDATE");

    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 276 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 276 "StaticSQL.sqc"
        sqlaaloc(2, 3, 5, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 276 "StaticSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 276 "StaticSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 276 "StaticSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 276 "StaticSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 276 "StaticSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 276 "StaticSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 276 "StaticSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 276 "StaticSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 276 "StaticSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 276 "StaticSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 276 "StaticSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 276 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 276 "StaticSQL.sqc"



    /*
    EXEC SQL UPDATE EMPLOYEE SET FIRSTNME = :FirstName, LASTNAME = :LastName, EDLEVEL = :EdLevel, SALARY = :Salary WHERE EMPNO = :EmployeeNo;
    */

    {
#line 278 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 278 "StaticSQL.sqc"
        sqlaaloc(2, 5, 6, 0L);
        {
            struct sqla_setdata_list sql_setdlist[5];
#line 278 "StaticSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 13;
#line 278 "StaticSQL.sqc"
            sql_setdlist[0].sqldata = (void*)FirstName;
#line 278 "StaticSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 278 "StaticSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 16;
#line 278 "StaticSQL.sqc"
            sql_setdlist[1].sqldata = (void*)LastName;
#line 278 "StaticSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 278 "StaticSQL.sqc"
            sql_setdlist[2].sqltype = 496; sql_setdlist[2].sqllen = 4;
#line 278 "StaticSQL.sqc"
            sql_setdlist[2].sqldata = (void*)&EdLevel;
#line 278 "StaticSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 278 "StaticSQL.sqc"
            sql_setdlist[3].sqltype = 480; sql_setdlist[3].sqllen = 8;
#line 278 "StaticSQL.sqc"
            sql_setdlist[3].sqldata = (void*)&Salary;
#line 278 "StaticSQL.sqc"
            sql_setdlist[3].sqlind = 0L;
#line 278 "StaticSQL.sqc"
            sql_setdlist[4].sqltype = 460; sql_setdlist[4].sqllen = 7;
#line 278 "StaticSQL.sqc"
            sql_setdlist[4].sqldata = (void*)EmployeeNo;
#line 278 "StaticSQL.sqc"
            sql_setdlist[4].sqlind = 0L;
#line 278 "StaticSQL.sqc"
            sqlasetdata(2, 0, 5, sql_setdlist, 0L, 0L);
        }
#line 278 "StaticSQL.sqc"
        sqlacall((unsigned short)24, 3, 2, 0, 0L);
#line 278 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 278 "StaticSQL.sqc"

    if (sqlca.sqlcode == 0) {
        printf("Employee updated successfully.\n");
    }
    else {
        printf("Failed to update employee.\n");
        handleSqlcaError();
    }

    // Commit The Transaction

 /*
 EXEC SQL COMMIT;
 */

    {
#line 287 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 287 "StaticSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 287 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 287 "StaticSQL.sqc"


    // Disconnect from the database

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 290 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 290 "StaticSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 290 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 290 "StaticSQL.sqc"

}

void deleteEmployee() {
    // Use EXEC SQL statements and host variables to perform the delete operation

/*
EXEC SQL BEGIN DECLARE SECTION;
*/

#line 295 "StaticSQL.sqc"

    char     EmployeeNo[7];

    /*
    EXEC SQL END DECLARE SECTION;
    */

#line 297 "StaticSQL.sqc"


    strcpy(EmployeeNo, getInput("EMPNO TO DELETE", 6));

    // Connect to the appropriate database

/*
EXEC SQL CONNECT TO SAMPLE USER sjm USING sujiaming;
*/

    {
#line 302 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 302 "StaticSQL.sqc"
        sqlaaloc(2, 3, 7, 0L);
        {
            struct sqla_setdata_list sql_setdlist[3];
#line 302 "StaticSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 302 "StaticSQL.sqc"
            sql_setdlist[0].sqldata = (void*)"SAMPLE";
#line 302 "StaticSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 302 "StaticSQL.sqc"
            sql_setdlist[1].sqltype = 460; sql_setdlist[1].sqllen = 4;
#line 302 "StaticSQL.sqc"
            sql_setdlist[1].sqldata = (void*)"sjm";
#line 302 "StaticSQL.sqc"
            sql_setdlist[1].sqlind = 0L;
#line 302 "StaticSQL.sqc"
            sql_setdlist[2].sqltype = 460; sql_setdlist[2].sqllen = 10;
#line 302 "StaticSQL.sqc"
            sql_setdlist[2].sqldata = (void*)"sujiaming";
#line 302 "StaticSQL.sqc"
            sql_setdlist[2].sqlind = 0L;
#line 302 "StaticSQL.sqc"
            sqlasetdata(2, 0, 3, sql_setdlist, 0L, 0L);
        }
#line 302 "StaticSQL.sqc"
        sqlacall((unsigned short)29, 5, 2, 0, 0L);
#line 302 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 302 "StaticSQL.sqc"



    /*
    EXEC SQL DELETE FROM EMPLOYEE WHERE EMPNO = :EmployeeNo;
    */

    {
#line 304 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 304 "StaticSQL.sqc"
        sqlaaloc(2, 1, 8, 0L);
        {
            struct sqla_setdata_list sql_setdlist[1];
#line 304 "StaticSQL.sqc"
            sql_setdlist[0].sqltype = 460; sql_setdlist[0].sqllen = 7;
#line 304 "StaticSQL.sqc"
            sql_setdlist[0].sqldata = (void*)EmployeeNo;
#line 304 "StaticSQL.sqc"
            sql_setdlist[0].sqlind = 0L;
#line 304 "StaticSQL.sqc"
            sqlasetdata(2, 0, 1, sql_setdlist, 0L, 0L);
        }
#line 304 "StaticSQL.sqc"
        sqlacall((unsigned short)24, 4, 2, 0, 0L);
#line 304 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 304 "StaticSQL.sqc"

    if (sqlca.sqlcode == 0) {
        printf("Employee deleted successfully.\n");
    }
    else {
        printf("Failed to delete employee.\n");
        handleSqlcaError();
    }

    // Commit The Transaction

 /*
 EXEC SQL COMMIT;
 */

    {
#line 313 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 313 "StaticSQL.sqc"
        sqlacall((unsigned short)21, 0, 0, 0, 0L);
#line 313 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 313 "StaticSQL.sqc"


    // Disconnect from the database

/*
EXEC SQL DISCONNECT CURRENT;
*/

    {
#line 316 "StaticSQL.sqc"
        sqlastrt(sqla_program_id, &sqla_rtinfo, &sqlca);
#line 316 "StaticSQL.sqc"
        sqlacall((unsigned short)40, 24, 0, 0, 0L);
#line 316 "StaticSQL.sqc"
        sqlastop(0L);
    }

#line 316 "StaticSQL.sqc"

}