package org.example;

import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class EmployeeManager {
    // SQL语句常量定义
    private static final String INSERT_SQL = "INSERT INTO EMPLOYEE (EMPNO, FIRSTNME, MIDINIT, LASTNAME, EDLEVEL) VALUES (?, ?, ?, ?, ?)";
    private static final String SELECT_ALL_SQL = "SELECT EMPNO, LASTNAME FROM EMPLOYEE";
    private static final String SELECT_BY_ID_SQL = "SELECT EMPNO, FIRSTNME, MIDINIT, LASTNAME, EDLEVEL FROM EMPLOYEE WHERE EMPNO = ?";
    private static final String UPDATE_SQL = "UPDATE EMPLOYEE SET FIRSTNME = ?, MIDINIT = ?, LASTNAME = ?, EDLEVEL = ? WHERE EMPNO = ?";
    private static final String DELETE_SQL = "DELETE FROM EMPLOYEE WHERE EMPNO = ?";
    private static final String CHECK_EXISTENCE_SQL = "SELECT EMPNO FROM EMPLOYEE WHERE EMPNO = ?";

    /**
     * 插入新的员工记录
     * @param con 数据库连接对象
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    public static void insertEmployee(Connection con) throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n\nInsert into EMPLOYEE");
        System.out.print("Enter EMPNO: ");
        String empNo = scanner.nextLine();

        // 检查员工编号长度是否超过6个字符
        if (empNo.length() > 6) {
            System.out.println("EMPNO must be within 6 characters. Insertion failed.");
            return;
        }

        // 检查员工是否已存在
        if (isEmployeeExists(con, empNo)) {
            System.out.println("Employee with ID " + empNo + " already exists. Insertion failed.");
            return;
        }

        // 获取员工的其他信息
        System.out.print("Enter FIRSTNME: ");
        String firstName = scanner.nextLine();
        if (firstName.length() > 12) {
            System.out.println("FIRSTNME must be within 12 characters. Insertion failed.");
            return;
        }

        System.out.print("Enter MIDINIT: ");
        String midInit = scanner.nextLine();
        if (midInit.length() != 1) {
            System.out.println("MIDINIT must be a single character. Insertion failed.");
            return;
        }

        System.out.print("Enter LASTNAME: ");
        String lastName = scanner.nextLine();
        if (lastName.length() > 15) {
            System.out.println("LASTNAME must be within 15 characters. Insertion failed.");
            return;
        }

        System.out.print("Enter EDLEVEL: ");
        int edLevel;
        try {
            edLevel = scanner.nextInt();
            scanner.nextLine(); // 清除输入缓冲区中的换行符
        } catch (InputMismatchException e) {
            System.out.println("EDLEVEL must be an integer. Insertion failed.");
            scanner.nextLine();
            return;
        }

        // 执行插入操作
        try (PreparedStatement pstmt = con.prepareStatement(INSERT_SQL)) {
            pstmt.setString(1, empNo);
            pstmt.setString(2, firstName);
            pstmt.setString(3, midInit);
            pstmt.setString(4, lastName);
            pstmt.setInt(5, edLevel);
            pstmt.executeUpdate();
            System.out.println("Record inserted successfully.");
        }
    }

    /**
     * 查询员工记录
     * @param con 数据库连接对象
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    public static void selectFromEmployee(Connection con) throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n\nSelect from EMPLOYEE");
        System.out.println("1. Select all employees");
        System.out.println("2. Select employee by ID");
        System.out.print("Enter your choice: ");
        int choice;
        if (scanner.hasNextInt()) {
            choice = scanner.nextInt();
            scanner.nextLine(); // 清除输入缓冲区中的换行符
        } else {
            System.out.println("Invalid choice. Please enter a valid integer choice.");
            scanner.nextLine();
            return;
        }

        // 根据用户的选择调用相应的方法
        switch (choice) {
            case 1:
                selectAllEmployees(con);
                break;
            case 2:
                System.out.print("Enter EMPNO: ");
                String empNo = scanner.next();
                if (empNo.length() > 6) {
                    System.out.println("EMPNO must be within 6 characters. Selection failed.");
                    return;
                }
                selectEmployeeById(con, empNo);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    /**
     * 查询所有员工记录
     * @param con 数据库连接对象
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    private static void selectAllEmployees(Connection con) throws SQLException {
        try (Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_ALL_SQL)) {
            System.out.println("Employee #  Employee surname");
            while (rs.next()) {
                System.out.println(rs.getString(1) + "      " + rs.getString(2));
            }
        }
    }

    /**
     * 根据员工编号查询员工记录
     * @param con 数据库连接对象
     * @param empNo 员工编号
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    private static void selectEmployeeById(Connection con, String empNo) throws SQLException {
        try (PreparedStatement pstmt = con.prepareStatement(SELECT_BY_ID_SQL)) {
            pstmt.setString(1, empNo);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("EMPNO: " + rs.getString(1));
                    System.out.println("FIRSTNME: " + rs.getString(2));
                    System.out.println("MIDINIT: " + rs.getString(3));
                    System.out.println("LASTNAME: " + rs.getString(4));
                    System.out.println("EDLEVEL: " + rs.getInt(5));
                } else {
                    System.out.println("Employee with ID " + empNo + " does not exist.");
                }
            }
        }
    }

    /**
     * 更新员工记录
     * @param con 数据库连接对象
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    public static void updateEmployee(Connection con) throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n\nUpdate EMPLOYEE");
        System.out.print("Enter EMPNO of the employee to update: ");
        String empNo = scanner.nextLine();

        // 检查员工编号长度是否超过6个字符
        if (empNo.length() > 6) {
            System.out.println("EMPNO must be within 6 characters. Update failed.");
            return;
        }

        // 检查员工是否存在
        if (!isEmployeeExists(con, empNo)) {
            System.out.println("Employee with ID " + empNo + " does not exist. Update failed.");
            return;
        }

        // 获取员工的新信息
        System.out.print("Enter New FIRSTNME: ");
        String firstName = scanner.nextLine();
        if (firstName.length() > 12) {
            System.out.println("FIRSTNME must be within 12 characters. Update failed.");
            return;
        }

        System.out.print("Enter New MIDINIT: ");
        String midInit = scanner.nextLine();
        if (midInit.length() != 1) {
            System.out.println("MIDINIT must be a single character. Update failed.");
            return;
        }

        System.out.print("Enter New LASTNAME: ");
        String lastName = scanner.nextLine();
        if (lastName.length() > 15) {
            System.out.println("LASTNAME must be within 15 characters. Update failed.");
            return;
        }

        System.out.print("Enter New EDLEVEL: ");
        int edLevel;
        try {
            edLevel = scanner.nextInt();
            scanner.nextLine(); // 清除输入缓冲区中的换行符
        } catch (InputMismatchException e) {
            System.out.println("EDLEVEL must be an integer. Update failed.");
            scanner.nextLine();
            return;
        }

        // 执行更新操作
        try (PreparedStatement pstmt = con.prepareStatement(UPDATE_SQL)) {
            pstmt.setString(1, firstName);
            pstmt.setString(2, midInit);
            pstmt.setString(3, lastName);
            pstmt.setInt(4, edLevel);
            pstmt.setString(5, empNo);
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " record(s) updated successfully.");
        }
    }

    /**
     * 删除员工记录
     * @param con 数据库连接对象
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    public static void deleteFromEmployee(Connection con) throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n\nDelete from EMPLOYEE");
        System.out.print("Enter EMPNO of the employee to delete: ");
        String empNo = scanner.nextLine();

        // 检查员工编号长度是否超过6个字符
        if (empNo.length() > 6) {
            System.out.println("EMPNO must be within 6 characters. Deletion failed.");
            return;
        }

        // 检查员工是否存在
        if (!isEmployeeExists(con, empNo)) {
            System.out.println("Employee with ID " + empNo + " does not exist. Deletion failed.");
            return;
        }

        // 执行删除操作
        try (PreparedStatement pstmt = con.prepareStatement(DELETE_SQL)) {
            pstmt.setString(1, empNo);
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " record(s) deleted successfully.");
        }
    }

    /**
     * 检查员工是否存在
     * @param con 数据库连接对象
     * @param empNo 员工编号
     * @return 如果员工存在则返回true，否则返回false
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    private static boolean isEmployeeExists(Connection con, String empNo) throws SQLException {
        try (PreparedStatement pstmt = con.prepareStatement(CHECK_EXISTENCE_SQL)) {
            pstmt.setString(1, empNo);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }
}

