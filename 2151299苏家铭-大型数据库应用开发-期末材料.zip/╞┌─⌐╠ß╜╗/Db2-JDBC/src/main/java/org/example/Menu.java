package org.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class Menu {

    /**
     * 显示主菜单并处理用户输入的选择
     * @param con 数据库连接对象
     * @throws SQLException 如果在与数据库的交互中发生错误
     */
    public static void displayMainMenu(Connection con) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        int choice = -1;

        do {
            // 打印主菜单
            System.out.println("\n\n\n\n\n=============================");
            System.out.println("EMPLOYEE MANAGEMENT SYSTEM");
            System.out.println("=============================");
            System.out.println("Main Menu:");
            System.out.println("1. Insert into EMPLOYEE");
            System.out.println("2. Select from EMPLOYEE");
            System.out.println("3. Update EMPLOYEE");
            System.out.println("4. Delete from EMPLOYEE");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            // 读取用户输入并验证
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // 清除输入缓冲区中的换行符
            } else {
                System.out.println("Invalid choice. Please enter a valid integer choice.");
                scanner.nextLine(); // 清除输入缓冲区中的无效输入
                continue;
            }

            // 根据用户选择调用相应的方法
            switch (choice) {
                case 1:
                    EmployeeManager.insertEmployee(con); // 插入员工记录
                    break;
                case 2:
                    EmployeeManager.selectFromEmployee(con); // 查询员工记录
                    break;
                case 3:
                    EmployeeManager.updateEmployee(con); // 更新员工记录
                    break;
                case 4:
                    EmployeeManager.deleteFromEmployee(con); // 删除员工记录
                    break;
                case 0:
                    System.out.println("Exiting..."); // 退出程序
                    break;
                default:
                    System.out.println("Invalid choice. Please try again."); // 处理无效选择
            }
        } while (choice != 0); // 当用户选择0时退出循环
    }
}
