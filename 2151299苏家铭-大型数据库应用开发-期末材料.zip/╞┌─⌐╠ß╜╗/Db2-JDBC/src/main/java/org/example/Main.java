package org.example;

import java.sql.Connection;
import java.sql.SQLException;

public class Main {

  // 程序的入口点
  public static void main(String[] argv) {
    Connection con = null; // 声明数据库连接对象
    try {
      // 加载DB2 JDBC驱动程序
      Class.forName("com.ibm.db2.jcc.DB2Driver");
      // 获取数据库连接
      con = DatabaseCon.getConnection();
      // 设置自动提交模式为true
      con.setAutoCommit(true);

      // 显示主菜单并进行相应操作
      Menu.displayMainMenu(con);
    } catch (ClassNotFoundException e) {
      // 捕获并处理类未找到异常
      System.err.println("Could not load JDBC driver");
      e.printStackTrace();
    } catch (SQLException e) {
      // 捕获并处理SQL异常
      handleSQLException(e);
    } finally {
      // 关闭数据库连接
      DatabaseCon.closeConnection(con);
    }
  }

  // 处理SQL异常的方法
  private static void handleSQLException(SQLException sqlEx) {
    while (sqlEx != null) {
      System.err.println("SQLException information");
      System.err.println("Error msg: " + sqlEx.getMessage()); // 输出错误信息
      System.err.println("SQLSTATE: " + sqlEx.getSQLState()); // 输出SQL状态码
      System.err.println("Error code: " + sqlEx.getErrorCode()); // 输出错误代码
      sqlEx.printStackTrace(); // 打印堆栈跟踪
      sqlEx = sqlEx.getNextException(); // 获取下一个异常
    }
  }
}
